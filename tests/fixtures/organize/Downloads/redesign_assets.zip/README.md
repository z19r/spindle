Acme Corp website redesign assets: logo variants and brand palette for the new homepage.
